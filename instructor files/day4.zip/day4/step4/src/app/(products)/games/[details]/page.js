export default function GamesArgs({params}) {
    return (
      <main>
        <h2>Quantity : { params.details+"" }</h2>
      </main>
    )
  }
  