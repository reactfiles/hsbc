export default function Games() {
    return (
      <main>
        <h2>Games Page</h2>
      </main>
    )
  }
  