export default function Movies() {
    return (
      <main>
        <h2>Movies Page</h2>
      </main>
    )
  }
  