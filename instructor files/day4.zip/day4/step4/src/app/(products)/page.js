export default function Product() {
    return (
      <main>
        <h2>Products Page</h2>
      </main>
    )
  }
  