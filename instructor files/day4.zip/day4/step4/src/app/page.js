export default function Home() {
  return (
    <main>
      <h1>Heroes Application</h1>
    </main>
  )
}
