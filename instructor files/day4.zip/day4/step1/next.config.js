const nextConfig = {
    reactStrictMode: true,
}