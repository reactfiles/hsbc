function About() {
    return (
      <article>
        <h1>Welcome to the About Page </h1>
      </article>
    )
  }
export default About;