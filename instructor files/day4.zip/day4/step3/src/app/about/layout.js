let AboutLayout = ({children})=>{
    return <section>
                <p> Layout for Child component</p>
                { children }
           </section>
}

export default AboutLayout