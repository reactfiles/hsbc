import Child from "./child";

export default function Home() {
  return (
    <main>
      <h1>Welcome to the workshop</h1>
      <Child version={101} title="One"/>
      <Child version={201} title="Two"/>
      <Child version={301} title="Three"/>
    </main>
  )
}
