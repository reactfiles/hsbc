"use client";

import React,{ useState } from "react";

export default function Child({ title, version }) {
  let [power, setPower] = useState(0);
  // let ipNum = useRef(); // function component
  let ipNum = React.createRef(); // class components
    return (
      <div>
        <h2>Child Component</h2>
        <h3>title : { title }</h3>
        <h3>version : { version * 2 }</h3>
        <h3>Power : {power }</h3>
        <button onClick={()=> setPower(power + 1) }>Increase Power</button>
        <input type="range" min="0" max="10" step="1" onInput={ (evt)=> setPower(Number(evt.target.value))}/>
        <br/>
        <input ref={ipNum} type="number" min="0" max="10" step="1"/>
        <button onClick={()=> setPower(Number( ipNum.current.value ))}>Increase Power from Number</button>
      </div>
    )
  }

  /* 
    assignement
    set power from input type range 
    set power from input type number using the button 
  */
  