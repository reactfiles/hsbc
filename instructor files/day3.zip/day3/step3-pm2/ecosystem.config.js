module.exports = {
  apps : [{
    name : "My HSBC APP",
    script: 'index.js',
    instances : 4,
    autorestart : true
    }
   ]
};
