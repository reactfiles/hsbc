for(let i = 0; i < 10**10; i++){
    // document.getElementById("log").textContent = i;
    postMessage(i);
}