const http = require("http");

const server = http.createServer((req, res) => {
    if(req.url == "/"){
        res.writeHead(200, { "Content-Type" : "text/plain"});
        res.end("welcome to home page")
    }else if(req.url == "/delay"){
        let count = 0;
        let start = Date.now();
        for(let i = 0; i < 10**10; i++){
            count++;
        };
        res.writeHead(200, { "Content-Type" : "text/plain"});
        res.write("Initial Value \n");
        res.end(`delayed page ${ (Date.now() - start) / 1000} seconds was taken to count till ${count}`);
    }else{
         res.end("404 page")
    }
});

server.listen(5000, () => console.log("server is running on port 5000 "));