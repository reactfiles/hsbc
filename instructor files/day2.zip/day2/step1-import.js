let obj = require("./step1");

console.log(obj);