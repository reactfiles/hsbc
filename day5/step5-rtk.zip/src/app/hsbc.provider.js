"use client";

const { Provider } = require("react-redux")
const store = require("./redux/store")

let HSBCProvider = ({ children })=>{
    return <Provider store={store}>{ children }</Provider>
};

export default HSBCProvider;