import HeroComp from "./hero.comp";
import HSBCProvider from "./hsbc.provider";

export default function Home() {
  return (
    <main>
      <HSBCProvider> <HeroComp/> </HSBCProvider>
    
    </main>
  )
}
