"use client";

import { useDispatch, useSelector } from "react-redux";
import { heroActions } from "../app/redux/features/hero/hero.slice";

let HeroComp = () =>{
let numOfHeroes = useSelector( state => state.hero.numOfHeroes );
let dispatch = useDispatch();

    return <div>
                <h1>Hero Component</h1>
                <h2>Heroes Count : { numOfHeroes }</h2>
                <button onClick={() => dispatch( heroActions.addHero() )}>Increase Hero Count</button>
                <button onClick={() => dispatch( heroActions.removeHero() )}>Decrease Hero Count</button>
                <button onClick={() => dispatch( heroActions.resetHero(10) )}>Set Hero Count to 10</button>
            </div>
} ;

export default HeroComp;