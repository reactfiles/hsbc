import Hero from "../hero";
import heroesdata from "../heroes.json";

let HeroesList = () => {
  return (
    <section>
      <h1>Heroes List</h1>
      { heroesdata.heroes.map((info) => <Hero  {...info}  key={info.id}/>)}
    </section>
  )
}

export default HeroesList