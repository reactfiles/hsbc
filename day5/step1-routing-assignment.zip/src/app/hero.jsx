import Image from "next/image";
import "./hero.css";
export default function Hero({ name, biography, image }) {
  return (
    <article className="hero">
      <h1>Hero Component</h1>
      <div>Title : { name }</div>
      <div>Name : { biography['full-name'] }</div>
      <Image priority src={image.url} width={200} height={200} alt={name} />
      <div className="btn">Details</div>
    </article>
  )
}