import Hero from "../hero";
import heroesdata from "../heroes.json";

let HeroDetail = () => {
  return (
    <article>
      <h1>Hero Title</h1>
    </article>
  )
}

export default HeroDetail