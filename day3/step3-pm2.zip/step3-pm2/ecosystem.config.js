module.exports = {
  apps : [{
    name : "My HSBC APP",
    script: 'index.js',
    instances : 5,
    autorestart : true
    }
   ]
};
